const catalog = [
  {name: "Кирпич керамический М150", category: "Кирпич и блоки", price: "от 18 ₽ / шт", image: "images/brick.jpg"},
  {name: "Газоблок D500 600×250×200", category: "Кирпич и блоки", price: "от 145 ₽ / шт", image: "images/aerated.jpg"},
  {name: "Цемент М500 (50 кг)", category: "Сыпучие материалы", price: "от 410 ₽ / мешок", image: "images/cement.jpg"},
  {name: "Песок карьерный", category: "Сыпучие материалы", price: "от 450 ₽ / т", image: "images/sand.jpg"},
  {name: "Щебень 5–20", category: "Сыпучие материалы", price: "от 1 200 ₽ / т", image: "images/gravel.jpg"},
  {name: "Плита ПК 1.2×6.0", category: "ЖБИ и плиты", price: "от 12 900 ₽ / шт", image: "images/slab.jpg"},
  {name: "ФБС 24‑4‑6", category: "ЖБИ и плиты", price: "от 3 350 ₽ / шт", image: "images/fbs.jpg"},
  {name: "Профнастил НС‑35", category: "Кровля", price: "от 520 ₽ / м²", image: "images/roof.jpg"},
  {name: "Минвата 50 мм", category: "Отделочные материалы", price: "от 410 ₽ / м²", image: "images/insulation.jpg"},
  {name: "Гипсокартон 12.5 мм", category: "Дерево и листовые", price: "от 420 ₽ / лист", image: "images/drywall.jpg"},
  {name: "Доска обрезная 25×100×6", category: "Дерево и листовые", price: "от 14 500 ₽ / м³", image: "images/lumber.jpg"},
  {name: "Краска фасадная 10 л", category: "Отделочные материалы", price: "от 1 950 ₽ / кан.", image: "images/paint.jpg"}
];
